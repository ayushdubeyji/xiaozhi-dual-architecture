#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "camera_manager.hpp"
#include "thread_affinity.hpp"
#include "sentry_telemetry.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <ctime>
#include <sys/stat.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>

constexpr int SCREEN_WIDTH = 800;
constexpr int SCREEN_HEIGHT = 480;

inline bool pointInRect(int x, int y, int rx, int ry, int rw, int rh) {
    return (x >= rx && x <= (rx + rw) && y >= ry && y <= (ry + rh));
}

void drawFillRect(SDL_Renderer* ren, int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(ren, r, g, b, a);
    SDL_Rect rect = { x, y, w, h };
    SDL_RenderFillRect(ren, &rect);
}

void drawRect(SDL_Renderer* ren, int x, int y, int w, int h, uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    SDL_SetRenderDrawBlendMode(ren, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(ren, r, g, b, a);
    SDL_Rect rect = { x, y, w, h };
    SDL_RenderDrawRect(ren, &rect);
}

double getCpuUsagePercent() {
    static unsigned long long prev_user = 0, prev_nice = 0, prev_sys = 0, prev_idle = 0;
    std::ifstream stat_file("/proc/stat");
    if (!stat_file.is_open()) return 0.0;

    std::string cpu;
    unsigned long long user, nice, sys, idle, iowait, irq, softirq;
    stat_file >> cpu >> user >> nice >> sys >> idle >> iowait >> irq >> softirq;

    unsigned long long total = (user - prev_user) + (nice - prev_nice) + (sys - prev_sys) + (idle - prev_idle);
    unsigned long long work = (user - prev_user) + (nice - prev_nice) + (sys - prev_sys);

    prev_user = user; prev_nice = nice; prev_sys = sys; prev_idle = idle;
    if (total == 0) return 0.0;
    return (double)work / (double)total * 100.0;
}

double getMemoryRssMb() {
    std::ifstream statm("/proc/self/statm");
    if (!statm.is_open()) return 0.0;
    long pages = 0;
    statm >> pages >> pages; // resident pages
    long page_size = sysconf(_SC_PAGESIZE);
    return (double)(pages * page_size) / (1024.0 * 1024.0);
}

struct FastText {
    SDL_Texture* tex{nullptr};
    int w{0}, h{0};
    std::string last_str;

    void update(SDL_Renderer* ren, TTF_Font* font, const std::string& str, SDL_Color col) {
        if (str == last_str && tex) return;
        destroy();
        last_str = str;
        SDL_Surface* surf = TTF_RenderUTF8_Blended(font, str.c_str(), col);
        if (surf) {
            w = surf->w;
            h = surf->h;
            tex = SDL_CreateTextureFromSurface(ren, surf);
            SDL_FreeSurface(surf);
        }
    }

    void draw(SDL_Renderer* ren, int x, int y) {
        if (!tex) return;
        SDL_Rect r = { x, y, w, h };
        SDL_RenderCopy(ren, tex, NULL, &r);
    }

    void destroy() {
        if (tex) {
            SDL_DestroyTexture(tex);
            tex = nullptr;
        }
    }
};

int main(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    // Pin GUI render loop to CPU Core 3
    SystemPerf::pinToCore(3);
    SentryTelemetry::init();

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS) != 0) {
        std::cerr << "SDL_Init Error: " << SDL_GetError() << "\n";
        return 1;
    }

    if (TTF_Init() != 0) {
        std::cerr << "TTF_Init Error: " << TTF_GetError() << "\n";
        SDL_Quit();
        return 1;
    }

    mkdir("/home/ayush/Pictures", 0755);

    SDL_Window* window = SDL_CreateWindow(
        "Arducam IMX519 Modern 60FPS",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_WIDTH, SCREEN_HEIGHT,
        SDL_WINDOW_SHOWN | SDL_WINDOW_FULLSCREEN_DESKTOP
    );

    if (!window) {
        std::cerr << "Window Error: " << SDL_GetError() << "\n";
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(
        window, -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );

    if (!renderer) {
        std::cerr << "Renderer Error: " << SDL_GetError() << "\n";
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }

    TTF_Font* font_small = TTF_OpenFont("/usr/share/fonts/opentype/inter/Inter-Regular.otf", 13);
    if (!font_small) font_small = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 13);

    TTF_Font* font_medium = TTF_OpenFont("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 16);
    if (!font_medium) font_medium = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16);

    TTF_Font* font_large = TTF_OpenFont("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 18);
    if (!font_large) font_large = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18);

    CameraManager camera;
    camera.start(800, 480, 60);

    SDL_Texture* video_texture = SDL_CreateTexture(
        renderer,
        SDL_PIXELFORMAT_RGB24,
        SDL_TEXTUREACCESS_STREAMING,
        SCREEN_WIDTH, SCREEN_HEIGHT
    );

    bool running = true;
    bool show_settings = false;
    bool recording = false;
    int res_mode = 0; // 0=800x480, 1=1280x720
    std::string toast_message = "IMX519 Ultra-Low Footprint 60FPS Ready";
    auto toast_time = std::chrono::steady_clock::now();

    FastText text_hud, text_badge, text_toast, text_btn_af, text_btn_set, text_rec;
    FastText t_title, t_close, t_res, t_af, t_trig, t_foc, t_ae, t_exp, t_gain, t_awb, t_hint;

    float slider_exposure = 16.6f;
    float slider_gain = 1.0f;
    float slider_focus = 0.0f;
    bool auto_focus_enabled = true;
    bool auto_exposure_enabled = true;
    int awb_index = 0;
    const std::vector<std::string> awb_modes = {"Auto", "Daylight", "Cloudy", "Tungsten"};

    bool dragging_focus = false;
    bool dragging_exposure = false;
    bool dragging_gain = false;

    uint64_t fps_counter = 0;
    double smoothed_fps = 60.0;
    auto last_fps_calc = std::chrono::steady_clock::now();
    CameraFrame current_frame;

    const std::chrono::microseconds target_frame_time(16666); // ~60.0 FPS

    // Non-blocking UDP socket on port 8086 for camera focus from ESP32-S3 daemon
    int focus_udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (focus_udp_fd >= 0) {
        int flags = fcntl(focus_udp_fd, F_GETFL, 0);
        fcntl(focus_udp_fd, F_SETFL, flags | O_NONBLOCK);
        struct sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(8086);
        bind(focus_udp_fd, (struct sockaddr*)&addr, sizeof(addr));
    }

    while (running) {
        auto loop_start = std::chrono::steady_clock::now();

        // 1. Poll for focus adjustments from ESP32-S3 hollow encoder daemon over UDP
        if (focus_udp_fd >= 0) {
            char ubuf[64];
            ssize_t n = recv(focus_udp_fd, ubuf, sizeof(ubuf) - 1, 0);
            if (n > 0) {
                ubuf[n] = '\0';
                if (strncmp(ubuf, "CAM_FOCUS:", 10) == 0) {
                    float new_foc = std::strtof(ubuf + 10, nullptr);
                    slider_focus = std::clamp(new_foc, 0.0f, 10.0f);
                    auto_focus_enabled = false;
                    camera.setManualFocus(slider_focus);
                    std::stringstream ss;
                    ss << "Lens Focus: " << std::fixed << std::setprecision(1) << slider_focus << " dpt";
                    toast_message = ss.str();
                    toast_time = std::chrono::steady_clock::now();
                }
            }
        }

        SDL_Event ev;
        while (SDL_PollEvent(&ev)) {
            if (ev.type == SDL_QUIT) {
                running = false;
            } else if (ev.type == SDL_KEYDOWN) {
                if (ev.key.keysym.sym == SDLK_ESCAPE || ev.key.keysym.sym == SDLK_q) {
                    running = false;
                }
            } else if (ev.type == SDL_MOUSEWHEEL) {
                // Focus handler: continuous rotation without click toggle; sensitivity tuned (0.2 dpt per step)
                if (ev.wheel.y != 0) {
                    float step_dir = (ev.wheel.direction == SDL_MOUSEWHEEL_FLIPPED) ? -1.0f : 1.0f;
                    float delta = (float)ev.wheel.y * step_dir * 0.20f;
                    slider_focus = std::clamp(slider_focus + delta, 0.0f, 10.0f);
                    auto_focus_enabled = false;
                    camera.setManualFocus(slider_focus);
                    std::stringstream ss;
                    ss << "Lens Focus: " << std::fixed << std::setprecision(1) << slider_focus << " dpt";
                    toast_message = ss.str();
                    toast_time = std::chrono::steady_clock::now();
                }
            } else if (ev.type == SDL_MOUSEBUTTONUP || ev.type == SDL_FINGERUP) {
                dragging_focus = false;
                dragging_exposure = false;
                dragging_gain = false;
            } else if (ev.type == SDL_MOUSEMOTION || ev.type == SDL_FINGERMOTION) {
                if (show_settings) {
                    int tx = (ev.type == SDL_MOUSEMOTION) ? ev.motion.x : (int)(ev.tfinger.x * SCREEN_WIDTH);
                    int drawer_x = 480;

                    if (dragging_focus) {
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_focus = std::clamp(norm * 10.0f, 0.0f, 10.0f);
                        auto_focus_enabled = false;
                        camera.setManualFocus(slider_focus);
                    } else if (dragging_exposure) {
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_exposure = std::clamp(1.0f + norm * 32.0f, 1.0f, 33.0f);
                        auto_exposure_enabled = false;
                        camera.setExposure(false, (uint32_t)(slider_exposure * 1000.0f));
                    } else if (dragging_gain) {
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_gain = std::clamp(1.0f + norm * 15.0f, 1.0f, 16.0f);
                        camera.setGain(slider_gain);
                    }
                }
            } else if (ev.type == SDL_MOUSEBUTTONDOWN || ev.type == SDL_FINGERDOWN) {
                int tx = (ev.type == SDL_MOUSEBUTTONDOWN) ? ev.button.x : (int)(ev.tfinger.x * SCREEN_WIDTH);
                int ty = (ev.type == SDL_MOUSEBUTTONDOWN) ? ev.button.y : (int)(ev.tfinger.y * SCREEN_HEIGHT);

                if (show_settings) {
                    int drawer_x = 480;
                    if (pointInRect(tx, ty, 735, 10, 55, 40)) {
                        show_settings = false;
                    } else if (pointInRect(tx, ty, drawer_x + 20, 60, 280, 40)) {
                        res_mode = (res_mode + 1) % 2;
                        if (res_mode == 0) {
                            camera.switchResolution(800, 480, 60);
                            toast_message = "Mode: 800x480 @ 60 FPS";
                        } else {
                            camera.switchResolution(1280, 720, 60);
                            toast_message = "Mode: 1280x720 @ 60 FPS (16:9)";
                        }
                        toast_time = std::chrono::steady_clock::now();
                        if (video_texture) SDL_DestroyTexture(video_texture);
                        video_texture = SDL_CreateTexture(
                            renderer, SDL_PIXELFORMAT_RGB24, SDL_TEXTUREACCESS_STREAMING,
                            res_mode == 0 ? 800 : 1280, res_mode == 0 ? 480 : 720
                        );
                    } else if (pointInRect(tx, ty, drawer_x + 20, 110, 135, 45)) {
                        auto_focus_enabled = !auto_focus_enabled;
                        camera.setContinuousAutofocus(auto_focus_enabled);
                        toast_message = auto_focus_enabled ? "AF: Continuous AUTO" : "AF: Manual Mode";
                        toast_time = std::chrono::steady_clock::now();
                    } else if (pointInRect(tx, ty, drawer_x + 160, 110, 140, 45)) {
                        camera.triggerAutofocus();
                        toast_message = "Autofocus Search Triggered";
                        toast_time = std::chrono::steady_clock::now();
                    } else if (pointInRect(tx, ty, drawer_x + 20, 160, 280, 45)) {
                        dragging_focus = true;
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_focus = std::clamp(norm * 10.0f, 0.0f, 10.0f);
                        auto_focus_enabled = false;
                        camera.setManualFocus(slider_focus);
                    } else if (pointInRect(tx, ty, drawer_x + 20, 210, 135, 45)) {
                        auto_exposure_enabled = !auto_exposure_enabled;
                        camera.setExposure(auto_exposure_enabled, (uint32_t)(slider_exposure * 1000.0f));
                        toast_message = auto_exposure_enabled ? "AE: AUTO" : "AE: MANUAL";
                        toast_time = std::chrono::steady_clock::now();
                    } else if (pointInRect(tx, ty, drawer_x + 20, 260, 280, 45)) {
                        dragging_exposure = true;
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_exposure = std::clamp(1.0f + norm * 32.0f, 1.0f, 33.0f);
                        auto_exposure_enabled = false;
                        camera.setExposure(false, (uint32_t)(slider_exposure * 1000.0f));
                    } else if (pointInRect(tx, ty, drawer_x + 20, 310, 280, 45)) {
                        dragging_gain = true;
                        float norm = (float)(tx - (drawer_x + 20)) / 280.0f;
                        slider_gain = std::clamp(1.0f + norm * 15.0f, 1.0f, 16.0f);
                        camera.setGain(slider_gain);
                    } else if (pointInRect(tx, ty, drawer_x + 20, 370, 280, 48)) {
                        awb_index = (awb_index + 1) % awb_modes.size();
                        camera.setAwbMode(awb_index);
                        toast_message = "AWB: " + awb_modes[awb_index];
                        toast_time = std::chrono::steady_clock::now();
                    }
                } else {
                    // Top-Right Touch EXIT Button
                    if (pointInRect(tx, ty, 715, 4, 78, 38)) {
                        running = false;
                    }
                    // Shutter Snap Button at (715, 185, 70, 70)
                    else if (pointInRect(tx, ty, 715, 185, 70, 70)) {
                        char snap_name[128];
                        auto now_c = std::time(nullptr);
                        std::strftime(snap_name, sizeof(snap_name), "/home/ayush/Pictures/snap_%Y%m%d_%H%M%S.bmp", std::localtime(&now_c));
                        SDL_Surface* sshot = SDL_CreateRGBSurfaceWithFormat(0, SCREEN_WIDTH, SCREEN_HEIGHT, 24, SDL_PIXELFORMAT_RGB24);
                        if (sshot) {
                            SDL_RenderReadPixels(renderer, NULL, SDL_PIXELFORMAT_RGB24, sshot->pixels, sshot->pitch);
                            SDL_SaveBMP(sshot, snap_name);
                            SDL_FreeSurface(sshot);
                            toast_message = "Captured: " + std::string(snap_name);
                        }
                        toast_time = std::chrono::steady_clock::now();
                    }
                    // Video Rec Button at (720, 275, 60, 60)
                    else if (pointInRect(tx, ty, 720, 275, 60, 60)) {
                        recording = !recording;
                        toast_message = recording ? "Video Recording Active" : "Video Recording Stopped";
                        toast_time = std::chrono::steady_clock::now();
                    }
                    // Quick AF Trigger Button at (720, 95, 60, 60)
                    else if (pointInRect(tx, ty, 720, 95, 60, 60)) {
                        camera.triggerAutofocus();
                        toast_message = "Autofocus Search Active";
                        toast_time = std::chrono::steady_clock::now();
                    }
                    // Settings Drawer Open Button at (720, 355, 60, 60)
                    else if (pointInRect(tx, ty, 720, 355, 60, 60)) {
                        show_settings = true;
                    }
                }
            }
        }

        // Fetch Frame via Lockless Ring Buffer
        if (camera.getLatestFrame(current_frame) && !current_frame.data.empty()) {
            SDL_UpdateTexture(video_texture, NULL, current_frame.data.data(), current_frame.meta.width * 3);
        }

        SDL_RenderClear(renderer);

        if (res_mode == 0) {
            SDL_Rect screen_rect = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };
            SDL_RenderCopy(renderer, video_texture, NULL, &screen_rect);
        } else {
            SDL_Rect letterbox_rect = { 0, 15, SCREEN_WIDTH, 450 };
            SDL_RenderCopy(renderer, video_texture, NULL, &letterbox_rect);
        }

        // Draw Top Bar Telemetry HUD
        drawFillRect(renderer, 0, 0, SCREEN_WIDTH, 44, 15, 20, 26, 215);
        drawRect(renderer, 0, 43, SCREEN_WIDTH, 1, 60, 80, 100, 180);

        fps_counter++;
        auto now_time = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed_fps = now_time - last_fps_calc;
        if (elapsed_fps.count() >= 0.5) {
            smoothed_fps = fps_counter / elapsed_fps.count();
            fps_counter = 0;
            last_fps_calc = now_time;

            double ram_mb = getMemoryRssMb();
            double cpu_pct = getCpuUsagePercent();

            std::stringstream hud_ss;
            hud_ss << "FPS: " << std::fixed << std::setprecision(1) << smoothed_fps << "  |  "
                   << "RAM: " << std::fixed << std::setprecision(1) << ram_mb << " MB  |  "
                   << "CPU: " << (int)cpu_pct << "%  |  "
                   << (res_mode == 0 ? "800x480" : "1280x720");
            text_hud.update(renderer, font_small, hud_ss.str(), {240, 245, 250, 255});
        }

        bool is_live = (camera.getMode() == CameraMode::PHYSICAL_IMX519);
        if (is_live) {
            drawFillRect(renderer, 10, 8, 140, 28, 20, 120, 40, 220);
            text_badge.update(renderer, font_small, "● IMX519 LIVE", {220, 255, 220, 255});
            text_badge.draw(renderer, 22, 14);
        } else {
            drawFillRect(renderer, 10, 8, 160, 28, 20, 80, 140, 220);
            text_badge.update(renderer, font_small, "● SYNTHETIC 60FPS", {180, 240, 255, 255});
            text_badge.draw(renderer, 18, 14);
        }

        text_hud.draw(renderer, 185, 14);

        if (recording) {
            drawFillRect(renderer, 635, 10, 75, 24, 200, 30, 30, 230);
            text_rec.update(renderer, font_small, "● REC", {255, 255, 255, 255});
            text_rec.draw(renderer, 650, 14);
        }

        // Top-Right Touch EXIT Button
        if (!show_settings) {
            drawFillRect(renderer, 720, 8, 68, 28, 190, 35, 35, 235);
            drawRect(renderer, 720, 8, 68, 28, 255, 120, 120, 220);
            t_close.update(renderer, font_small, "✕ EXIT", {255, 255, 255, 255});
            t_close.draw(renderer, 731, 14);
        }

        std::chrono::duration<double> toast_dur = now_time - toast_time;
        if (toast_dur.count() < 2.5) {
            drawFillRect(renderer, 240, SCREEN_HEIGHT - 60, 320, 38, 20, 20, 25, 200);
            drawRect(renderer, 240, SCREEN_HEIGHT - 60, 320, 38, 80, 160, 240, 180);
            text_toast.update(renderer, font_small, toast_message, {255, 255, 255, 255});
            text_toast.draw(renderer, 260, SCREEN_HEIGHT - 50);
        }

        if (!show_settings) {
            // AF Button
            drawFillRect(renderer, 725, 95, 52, 52, 35, 45, 55, 190);
            drawRect(renderer, 725, 95, 52, 52, 100, 150, 200, 220);
            text_btn_af.update(renderer, font_small, "AF", {240, 240, 255, 255});
            text_btn_af.draw(renderer, 740, 112);

            // Shutter Button
            drawFillRect(renderer, 715, 185, 68, 68, 240, 240, 240, 200);
            drawFillRect(renderer, 722, 192, 54, 54, 220, 40, 40, 240);

            // Video Rec Button
            drawFillRect(renderer, 725, 275, 52, 52, 35, 45, 55, 190);
            drawRect(renderer, 725, 275, 52, 52, 220, 60, 60, 220);
            if (recording) {
                drawFillRect(renderer, 740, 290, 22, 22, 240, 40, 40, 255);
            } else {
                drawFillRect(renderer, 742, 292, 18, 18, 240, 40, 40, 255);
            }

            // SET Button
            drawFillRect(renderer, 725, 355, 52, 52, 35, 45, 55, 190);
            drawRect(renderer, 725, 355, 52, 52, 140, 150, 160, 220);
            text_btn_set.update(renderer, font_small, "SET", {240, 245, 255, 255});
            text_btn_set.draw(renderer, 735, 372);
        }

        if (show_settings) {
            int dx = 480;
            drawFillRect(renderer, dx, 0, 320, SCREEN_HEIGHT, 18, 24, 32, 245);
            drawRect(renderer, dx, 0, 1, SCREEN_HEIGHT, 80, 100, 120, 200);

            t_title.update(renderer, font_large, "Camera Settings", {255, 255, 255, 255});
            t_title.draw(renderer, dx + 20, 15);

            drawFillRect(renderer, 740, 12, 45, 34, 180, 40, 40, 220);
            t_close.update(renderer, font_medium, "X", {255, 255, 255, 255});
            t_close.draw(renderer, 755, 18);

            drawFillRect(renderer, dx + 20, 60, 280, 40, 40, 55, 75, 220);
            drawRect(renderer, dx + 20, 60, 280, 40, 80, 140, 200, 200);
            std::string res_label = (res_mode == 0) ? "Mode: 800x480 @ 60 FPS" : "Mode: 1280x720 @ 60 FPS";
            t_res.update(renderer, font_small, res_label, {240, 250, 255, 255});
            t_res.draw(renderer, dx + 35, 72);

            uint8_t af_r = auto_focus_enabled ? 30 : 60;
            uint8_t af_g = auto_focus_enabled ? 130 : 60;
            drawFillRect(renderer, dx + 20, 115, 130, 36, af_r, af_g, 80, 220);
            t_af.update(renderer, font_small, auto_focus_enabled ? "AF: AUTO" : "AF: MANUAL", {255, 255, 255, 255});
            t_af.draw(renderer, dx + 32, 124);

            drawFillRect(renderer, dx + 160, 115, 140, 36, 45, 60, 85, 220);
            t_trig.update(renderer, font_small, "Trigger Search", {230, 240, 255, 255});
            t_trig.draw(renderer, dx + 172, 124);

            std::stringstream foc_ss;
            foc_ss << "Lens Focus: " << std::fixed << std::setprecision(1) << slider_focus << " dpt";
            t_foc.update(renderer, font_small, foc_ss.str(), {200, 220, 240, 255});
            t_foc.draw(renderer, dx + 20, 160);
            drawFillRect(renderer, dx + 20, 180, 280, 16, 30, 40, 50, 255);
            int foc_fill = (int)((slider_focus / 10.0f) * 280.0f);
            drawFillRect(renderer, dx + 20, 180, foc_fill, 16, 70, 160, 240, 255);

            uint8_t ae_r = auto_exposure_enabled ? 30 : 60;
            uint8_t ae_g = auto_exposure_enabled ? 130 : 60;
            drawFillRect(renderer, dx + 20, 215, 130, 36, ae_r, ae_g, 80, 220);
            t_ae.update(renderer, font_small, auto_exposure_enabled ? "AE: AUTO" : "AE: MANUAL", {255, 255, 255, 255});
            t_ae.draw(renderer, dx + 32, 224);

            std::stringstream exp_ss;
            exp_ss << "Exposure: " << std::fixed << std::setprecision(1) << slider_exposure << " ms";
            t_exp.update(renderer, font_small, exp_ss.str(), {200, 220, 240, 255});
            t_exp.draw(renderer, dx + 20, 260);
            drawFillRect(renderer, dx + 20, 280, 280, 16, 30, 40, 50, 255);
            int exp_fill = (int)(((slider_exposure - 1.0f) / 32.0f) * 280.0f);
            drawFillRect(renderer, dx + 20, 280, exp_fill, 16, 240, 180, 60, 255);

            std::stringstream gain_ss;
            gain_ss << "Gain (ISO): " << std::fixed << std::setprecision(1) << slider_gain << "x";
            t_gain.update(renderer, font_small, gain_ss.str(), {200, 220, 240, 255});
            t_gain.draw(renderer, dx + 20, 310);
            drawFillRect(renderer, dx + 20, 330, 280, 16, 30, 40, 50, 255);
            int gain_fill = (int)(((slider_gain - 1.0f) / 15.0f) * 280.0f);
            drawFillRect(renderer, dx + 20, 330, gain_fill, 16, 220, 100, 60, 255);

            drawFillRect(renderer, dx + 20, 375, 280, 40, 40, 55, 75, 220);
            drawRect(renderer, dx + 20, 375, 280, 40, 80, 140, 200, 200);
            t_awb.update(renderer, font_small, "AWB: " + awb_modes[awb_index], {240, 250, 255, 255});
            t_awb.draw(renderer, dx + 35, 387);

            t_hint.update(renderer, font_small, "Touch or drag sliders to adjust", {150, 170, 190, 255});
            t_hint.draw(renderer, dx + 25, 435);
        }

        SDL_RenderPresent(renderer);

        auto loop_end = std::chrono::steady_clock::now();
        auto elapsed_loop = std::chrono::duration_cast<std::chrono::microseconds>(loop_end - loop_start);
        if (elapsed_loop < target_frame_time) {
            std::this_thread::sleep_for(target_frame_time - elapsed_loop);
        }
    }

    camera.stop();

    text_hud.destroy();
    text_badge.destroy();
    text_toast.destroy();
    text_btn_af.destroy();
    text_btn_set.destroy();
    text_rec.destroy();

    t_title.destroy();
    t_close.destroy();
    t_res.destroy();
    t_af.destroy();
    t_trig.destroy();
    t_foc.destroy();
    t_ae.destroy();
    t_exp.destroy();
    t_gain.destroy();
    t_awb.destroy();
    t_hint.destroy();

    if (video_texture) SDL_DestroyTexture(video_texture);
    if (renderer) SDL_DestroyRenderer(renderer);
    if (window) SDL_DestroyWindow(window);
    if (font_small) TTF_CloseFont(font_small);
    if (font_medium) TTF_CloseFont(font_medium);
    if (font_large) TTF_CloseFont(font_large);
    TTF_Quit();
    SDL_Quit();

    SentryTelemetry::shutdown();
    if (focus_udp_fd >= 0) close(focus_udp_fd);
    std::cout << "[GUI] Clean exit completed.\n";
    return 0;
}
