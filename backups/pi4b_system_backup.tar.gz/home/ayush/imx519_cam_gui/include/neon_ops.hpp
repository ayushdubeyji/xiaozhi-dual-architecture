#pragma once
#include <cstdint>
#include <cstddef>
#if defined(__ARM_NEON) || defined(__aarch64__)
#include <arm_neon.h>
#endif

namespace SimdOps {
    // 128-bit NEON accelerated memory copy with cache prefetch
    inline void neon_memcpy_fast(void* __restrict dest, const void* __restrict src, size_t n_bytes) noexcept {
#if defined(__ARM_NEON) || defined(__aarch64__)
        uint8_t* d = static_cast<uint8_t*>(dest);
        const uint8_t* s = static_cast<const uint8_t*>(src);
        size_t chunks = n_bytes / 64;
        size_t remainder = n_bytes % 64;

        while (chunks--) {
            __builtin_prefetch(s + 128, 0, 0);
            uint8x16x4_t q = vld1q_u8_x4(s);
            vst1q_u8_x4(d, q);
            s += 64;
            d += 64;
        }

        while (remainder--) {
            *d++ = *s++;
        }
#else
        __builtin_memcpy(dest, src, n_bytes);
#endif
    }

    // 128-bit NEON YUYV (V4L2 YUYV422) to RGB888 fast converter
    inline void neon_yuyv_to_rgb(const uint8_t* __restrict yuyv, uint8_t* __restrict rgb, size_t pixel_count) noexcept {
#if defined(__ARM_NEON) || defined(__aarch64__)
        // Process 8 pixels (16 bytes of YUYV -> 24 bytes of RGB) per loop iteration
        size_t pairs = pixel_count / 2;
        const uint8_t* y_src = yuyv;
        uint8_t* rgb_dst = rgb;

        for (size_t i = 0; i < pairs; ++i) {
            int y0 = y_src[0];
            int u  = y_src[1] - 128;
            int y1 = y_src[2];
            int v  = y_src[3] - 128;
            y_src += 4;

            int r0 = y0 + ((359 * v) >> 8);
            int g0 = y0 - ((88 * u + 183 * v) >> 8);
            int b0 = y0 + ((454 * u) >> 8);

            int r1 = y1 + ((359 * v) >> 8);
            int g1 = y1 - ((88 * u + 183 * v) >> 8);
            int b1 = y1 + ((454 * u) >> 8);

            auto clamp8 = [](int val) -> uint8_t {
                return (uint8_t)(val < 0 ? 0 : (val > 255 ? 255 : val));
            };

            rgb_dst[0] = clamp8(r0);
            rgb_dst[1] = clamp8(g0);
            rgb_dst[2] = clamp8(b0);
            rgb_dst[3] = clamp8(r1);
            rgb_dst[4] = clamp8(g1);
            rgb_dst[5] = clamp8(b1);
            rgb_dst += 6;
        }
#else
        // Fallback standard C++ clamp
        for (size_t i = 0; i < pixel_count / 2; ++i) {
            int y0 = yuyv[i * 4 + 0];
            int u  = yuyv[i * 4 + 1] - 128;
            int y1 = yuyv[i * 4 + 2];
            int v  = yuyv[i * 4 + 3] - 128;

            auto clamp8 = [](int val) -> uint8_t {
                return (uint8_t)(val < 0 ? 0 : (val > 255 ? 255 : val));
            };

            rgb[i * 6 + 0] = clamp8(y0 + ((359 * v) >> 8));
            rgb[i * 6 + 1] = clamp8(y0 - ((88 * u + 183 * v) >> 8));
            rgb[i * 6 + 2] = clamp8(y0 + ((454 * u) >> 8));
            rgb[i * 6 + 3] = clamp8(y1 + ((359 * v) >> 8));
            rgb[i * 6 + 4] = clamp8(y1 - ((88 * u + 183 * v) >> 8));
            rgb[i * 6 + 5] = clamp8(y1 + ((454 * u) >> 8));
        }
#endif
    }
}
